# WebPerk AI Chatbot & Shop System

WebPerk is an AI-powered chatbot and e-commerce system for recommending and selling computers, laptops, accessories, and web apps.  
It includes:
- **FastAPI backend** (orders, deliveries, riders, payments)
- **Postgres database**
- **React Admin UI**
- **Rider app (React Native/Expo mockup)**

---

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose installed
- Node.js (for Admin UI development, optional)

### 1. Clone & unzip project
```bash
unzip webperk_project_with_compose.zip -d webperk
cd webperk
```

### 2. Start services
```bash
docker-compose up --build
```

This starts:
- **Postgres DB** → `localhost:5432`
- **FastAPI backend** → `http://localhost:8000`
- **Admin UI** → `http://localhost:3000`

### 3. Run database migrations
```bash
docker exec -it webperk-backend-1 bash
alembic upgrade head
```

### 4. Test backend
Open in browser:  
👉 [http://localhost:8000](http://localhost:8000)  
👉 [http://localhost:8000/docs](http://localhost:8000/docs) (Swagger UI)

### 5. Admin UI
Open React admin panel at:  
👉 [http://localhost:3000](http://localhost:3000)

### 6. Rider App
Inside `/rider-app`, run:
```bash
npm install -g expo-cli
npm install
expo start
```
Scan QR code in Expo Go app to run on your phone.

---

## 📂 Project Structure
```
backend/         # FastAPI backend (orders, deliveries, payments)
admin-ui/        # React Admin UI
rider-app/       # React Native Rider app (Expo)
migrations/      # SQL migrations for Postgres
docker-compose.yml
README.md
```

---

## 📞 Contact
- Shop Location: Nairobi CBD, Kenya
- Phone: **0717 776 1340**
- Currency: **KES (Kenyan Shillings)**

---

## ✅ Next Steps
- Integrate M-Pesa sandbox for payments
- Add order fulfillment logic to Admin UI
- Expand Rider App for live delivery tracking

