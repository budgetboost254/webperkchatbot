from sqlalchemy import Column, String, Integer, Float, Enum, ForeignKey, JSON, TIMESTAMP
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import enum

Base = declarative_base()

class RiderStatus(enum.Enum):
    available = 'available'
    on_ride = 'on_ride'
    offline = 'offline'

class DeliveryStatus(enum.Enum):
    preparing = 'preparing'
    out_for_delivery = 'out_for_delivery'
    arrived = 'arrived'
    delivered = 'delivered'
    failed = 'failed'
    returned = 'returned'

class Rider(Base):
    __tablename__ = 'riders'
    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    phone = Column(String, nullable=False)
    current_lat = Column(Float, nullable=True)
    current_lon = Column(Float, nullable=True)
    status = Column(Enum(RiderStatus), default=RiderStatus.available)
    vehicle_type = Column(String, nullable=True)
    rating = Column(Float, default=0.0)

class Zone(Base):
    __tablename__ = 'zones'
    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    radius_km = Column(Float, nullable=False)
    base_fee_kes = Column(Integer, nullable=False)
    per_km_fee_kes = Column(Integer, nullable=False)

class Delivery(Base):
    __tablename__ = 'deliveries'
    id = Column(String, primary_key=True)
    order_id = Column(String, unique=True, nullable=False)
    customer_id = Column(String, nullable=True)
    customer_phone = Column(String, nullable=True)
    delivery_address = Column(String, nullable=False)
    delivery_lat = Column(Float, nullable=True)
    delivery_lon = Column(Float, nullable=True)
    delivery_zone = Column(String, ForeignKey('zones.id'), nullable=True)
    delivery_fee_kes = Column(Integer, default=0)
    rider_id = Column(String, ForeignKey('riders.id'), nullable=True)
    delivery_status = Column(Enum(DeliveryStatus), default=DeliveryStatus.preparing)
    eta = Column(Integer, nullable=True)
    pod_url = Column(String, nullable=True)
    tracking_history = Column(JSON, default=list)
    created_at = Column(TIMESTAMP, nullable=False)
    updated_at = Column(TIMESTAMP, nullable=False)

    rider = relationship('Rider')
    zone = relationship('Zone')
