from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from models import Delivery, Rider, DeliveryStatus
from db import get_db
import time

router = APIRouter(prefix='/delivery')

@router.post('/assign')
async def assign_rider(order_id: str, db: Session = Depends(get_db)):
    delivery = db.query(Delivery).filter_by(order_id=order_id).first()
    if not delivery:
        raise HTTPException(status_code=404, detail='Order not found')
    rider = db.query(Rider).filter_by(status='available').first()
    if not rider:
        raise HTTPException(status_code=400, detail='No available riders')
    delivery.rider_id = rider.id
    delivery.delivery_status = DeliveryStatus.out_for_delivery
    db.add(delivery)
    rider.status = 'on_ride'
    db.add(rider)
    db.commit()
    return {'ok': True, 'rider_id': rider.id}

@router.post('/update-location')
async def update_location(rider_id: str, lat: float, lon: float, db: Session = Depends(get_db)):
    rider = db.query(Rider).get(rider_id)
    if not rider:
        raise HTTPException(status_code=404, detail='Rider not found')
    rider.current_lat = lat
    rider.current_lon = lon
    db.add(rider)
    delivery = db.query(Delivery).filter(Delivery.rider_id==rider_id, Delivery.delivery_status==DeliveryStatus.out_for_delivery).first()
    if delivery:
        entry = {'ts': int(time.time()), 'lat': lat, 'lon': lon}
        th = delivery.tracking_history or []
        th.append(entry)
        delivery.tracking_history = th
        db.add(delivery)
    db.commit()
    return {'ok': True}

@router.put('/{order_id}/status')
async def update_status(order_id: str, status: DeliveryStatus, db: Session = Depends(get_db)):
    delivery = db.query(Delivery).filter_by(order_id=order_id).first()
    if not delivery:
        raise HTTPException(status_code=404, detail='Order not found')
    delivery.delivery_status = status
    db.add(delivery)
    db.commit()
    return {'ok': True}

@router.get('/{order_id}/track')
async def track(order_id: str, db: Session = Depends(get_db)):
    delivery = db.query(Delivery).filter_by(order_id=order_id).first()
    if not delivery:
        raise HTTPException(status_code=404, detail='Order not found')
    rider_location = None
    if delivery.rider_id:
        rider = db.query(Rider).get(delivery.rider_id)
        rider_location = {'lat': rider.current_lat, 'lon': rider.current_lon}
    return {'order_id': order_id, 'eta': delivery.eta, 'rider_location': rider_location, 'tracking_history': delivery.tracking_history}
