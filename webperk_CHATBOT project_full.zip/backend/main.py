from fastapi import FastAPI
from delivery_api import router as delivery_router
from models import Base
from db import engine

app = FastAPI()

Base.metadata.create_all(bind=engine)

app.include_router(delivery_router)

@app.get('/')
async def root():
    return {'ok': True, 'service': 'webperk-backend'}
